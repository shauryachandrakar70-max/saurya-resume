# Saurya Pratap Chandrakar — Portfolio
Responsive dark editorial portfolio with an SPC identity, mobile navigation, scroll reveals, education, skills, experience timeline, award and certificate evidence gallery.

CSS concepts: element, class and ID selectors; variables; Flexbox; Grid; positioning; spacing; typography; responsive breakpoints; scroll snapping; reduced-motion support.

Before publishing, confirm Reach Craft spelling, dates, award/course names, and any metric you cannot substantiate. Add real headshot/certificate scans with the filenames in `assets/README.md`. This is a public portfolio: it shows both email addresses and omits phone, full address, DOB, blood group, and roll number.
