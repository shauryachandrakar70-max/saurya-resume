Add real images here, then upload them with the website. Replace the designed fallback artwork by using these exact filenames:
- saurya-headshot.jpg (real profile photo)
- bravery-award-2021.jpg
- skill-india-gda-certificate.jpg
- scouts-guides-training-2023.jpg
- computer-summer-camp.jpg
- gda-hospital-internship.jpg

This is a static site, so its image frames cannot upload files to a server. Copy the image into this folder and commit/upload it to GitHub. Publish only certificate scans you are allowed to share; crop/redact private IDs and addresses.
